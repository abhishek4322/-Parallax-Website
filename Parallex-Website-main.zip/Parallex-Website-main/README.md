# Parallex website
image gallery is made using Flexbox and its properties.
I am going to upload the same image gallery as well using the grid and its properties.
